<?php get_header(); ?>

<div id="container">
<div id="left-div">
    <div id="left-inside">
        <div style="font-size: 20px;"><?php esc_html_e('Sorry, the page your requested could not be found, or no longer exists.','LightSource'); ?> </div>
    </div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
</body>
</html>